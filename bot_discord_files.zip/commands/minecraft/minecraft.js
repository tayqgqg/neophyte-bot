const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('minecraft')
    .setDescription('Info server Minecraft'),
  async execute(interaction) {
    await interaction.reply('IP Server: play3.eternalzero.cloud:25807');
  },
};