const { SlashCommandBuilder } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } = require('@discordjs/voice');
const ytdl = require('ytdl-core');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Mainkan musik dari YouTube')
    .addStringOption(option =>
      option.setName('url')
        .setDescription('URL video YouTube')
        .setRequired(true)),
  async execute(interaction) {
    const url = interaction.options.getString('url');
    if (!ytdl.validateURL(url)) {
      return interaction.reply('URL tidak valid.');
    }

    const voiceChannel = interaction.member.voice.channel;
    if (!voiceChannel) {
      return interaction.reply('Kamu harus join voice channel terlebih dahulu!');
    }

    const connection = joinVoiceChannel({
      channelId: voiceChannel.id,
      guildId: interaction.guild.id,
      adapterCreator: interaction.guild.voiceAdapterCreator,
    });

    const stream = ytdl(url, { filter: 'audioonly' });
    const resource = createAudioResource(stream);
    const player = createAudioPlayer();

    player.play(resource);
    connection.subscribe(player);

    player.on(AudioPlayerStatus.Idle, () => connection.destroy());
    await interaction.reply(`Memutar: ${url}`);
  },
};